<?php

/**
 * @file
 * @author Your Name
 * Contains \Drupal\show_data\Controller\ShowDataController.
 */

namespace Drupal\show_data\Controller;

use Drupal\Core\Controller\ControllerBase;


/**
 * Provides route responses for the Test module.
 */
class ShowDataController extends ControllerBase {

  /**
   * Returns a simple page.
   *
   * @return array
   *   A simple renderable array.
   */


  public function ShowData() {
    $db = \Drupal::database();
    $query = $db->select('node_field_data','n');
    $query->condition('n.type', 'article', '=');
    $query->fields('n', ['nid']);
    $query->fields('n', ['title']);
    $query->fields('n', ['type']);
    $result = $query->execute()->fetchAll();
    $list_data = [];
    foreach ($result as $key => $value) {
      $list_data[$key]['nid'] = $value->nid;
      $list_data[$key]['title'] = $value->title;
      $list_data[$key]['type'] = $value->type;
    }   
    
    return [
      '#cache' => ['max-age' => 0],
      '#theme' => 'show_data_template',
      '#title' => 'Show List of Article content',
      '#data_list' => $list_data,
    ];
   
  }
}
